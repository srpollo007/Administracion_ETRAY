﻿//8
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Administracion_ETRAY
{
    public partial class Datosbar : Form
    {
        public Datosbar()
        {
            InitializeComponent();
            ProbarConexion();
            txtURL.Click += txtURL_Click;

            pictureBoxPDF.MouseEnter += (sender, e) => Utilidades.PictureBox_MouseEnter(pictureBoxPDF, sender, e);
            pictureBoxPDF.MouseLeave += (sender, e) => Utilidades.PictureBox_MouseLeave(pictureBoxPDF, sender, e);
        }
        private void ProbarConexion()
        {
            string cadenaConexion = Utilidades.ObtenerCadenaConexionDesdeXML();

            if (cadenaConexion != null)
            {
                Utilidades.ProbarConexion(cadenaConexion);
            }
        }
        private void btnInsert_Click(object sender, EventArgs e)
        {
            string nombre = txtNom_Produc.Text;
            string ubicacion = textBox1.Text;
            string descripcion = txtPrecio.Text;
            string rutaImagen = txtURL.Text;

            byte[] imagenBytes = Utilidades.ConvertirImagenABinario(rutaImagen);

            InsertarDatosBar(nombre, ubicacion, descripcion, imagenBytes);
            LimpiarCampos();
        }
        private void LimpiarCampos()
        {
            txtNom_Produc.Text = string.Empty;
            textBox1.Text = string.Empty;
            txtPrecio.Text = string.Empty;
            txtURL.Text = string.Empty;
            pictureBox1.Image = null;
        }
        private void txtURL_Click(object sender, EventArgs e)
        {
            Utilidades.SeleccionarYMostrarImagen(txtURL, pictureBox1);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Utilidades.SeleccionarYMostrarImagen(txtURL, pictureBox1);
        }

        private void lblTitulo_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtURL_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnInsert_Clickcomida(object sender, EventArgs e)
        {
            string nombre = txtNom_Produc.Text; // Asegúrate de que txtNombre es el nombre del TextBox correspondiente.
            string ubicacion = textBox1.Text; // Asegúrate de que txtUbicacion es el nombre del TextBox correspondiente.
            string descripcion = txtPrecio.Text; // Asegúrate de que txtDescripcion es el nombre del TextBox correspondiente.
            byte[] imagen = null;

            // Asegúrate de que pictureBoxLogo es el nombre del PictureBox correspondiente.
            if (pictureBox1.Image != null)
            {

            }

            InsertarDatosBar(nombre, ubicacion, descripcion, imagen);
        }

        private void InsertarDatosBar(string nombre, string ubicacion, string descripcion, byte[] imagen)
        {
            // Aquí iría tu cadena de conexión a la base de datos.
            string cadenaConexion = Utilidades.ObtenerCadenaConexionDesdeXML();

            try
            {
                using (MySqlConnection conexion = new MySqlConnection(cadenaConexion))
                {
                    conexion.Open();

                    string consulta = "INSERT INTO datosbar (nombre, ubicacion, descripcion, imagen) VALUES (@Nombre, @Ubicacion, @Descripcion, @Imagen)";

                    using (MySqlCommand comando = new MySqlCommand(consulta, conexion))
                    {
                        comando.Parameters.AddWithValue("@Nombre", nombre);
                        comando.Parameters.AddWithValue("@Ubicacion", ubicacion);
                        comando.Parameters.AddWithValue("@Descripcion", descripcion);
                        if (imagen != null)
                        {
                            comando.Parameters.AddWithValue("@Imagen", imagen);
                        }
                        else
                        {
                            comando.Parameters.AddWithValue("@Imagen", DBNull.Value);
                        }

                        comando.ExecuteNonQuery();

                        MessageBox.Show("Datos insertados correctamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show($"Error al insertar en la base de datos: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // Manejar otros posibles errores.
        }

        private void txtNom_Produc_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPrecio_TextChanged(object sender, EventArgs e)
        {

        }


        private void pictureBox1comida_Click(object sender, EventArgs e)
        {
            Utilidades.SeleccionarYMostrarImagen(txtURL, pictureBox1);
        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }
    }
}
