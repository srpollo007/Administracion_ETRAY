﻿namespace Administracion_ETRAY
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.nuevoProductoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bebidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarProductoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.precioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bebidaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.comidaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.nombreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comidaToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.bebidaToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.fotoGrafiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bebidaToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.comidaToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.editarDatosDeConexiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxPDF = new System.Windows.Forms.PictureBox();
            this.barToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPDF)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.DarkGray;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoProductoToolStripMenuItem,
            this.editarProductoToolStripMenuItem,
            this.editarDatosDeConexiToolStripMenuItem});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.Size = new System.Drawing.Size(1019, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // nuevoProductoToolStripMenuItem
            // 
            this.nuevoProductoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bebidaToolStripMenuItem,
            this.comidaToolStripMenuItem,
            this.barToolStripMenuItem});
            this.nuevoProductoToolStripMenuItem.Name = "nuevoProductoToolStripMenuItem";
            this.nuevoProductoToolStripMenuItem.Size = new System.Drawing.Size(130, 24);
            this.nuevoProductoToolStripMenuItem.Text = "Nuevo Producto";
            // 
            // bebidaToolStripMenuItem
            // 
            this.bebidaToolStripMenuItem.Name = "bebidaToolStripMenuItem";
            this.bebidaToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.bebidaToolStripMenuItem.Text = "Bebida";
            this.bebidaToolStripMenuItem.Click += new System.EventHandler(this.bebidaToolStripMenuItem_Click);
            // 
            // comidaToolStripMenuItem
            // 
            this.comidaToolStripMenuItem.Name = "comidaToolStripMenuItem";
            this.comidaToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.comidaToolStripMenuItem.Text = "Comida";
            this.comidaToolStripMenuItem.Click += new System.EventHandler(this.comidaToolStripMenuItem_Click);
            // 
            // editarProductoToolStripMenuItem
            // 
            this.editarProductoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.precioToolStripMenuItem,
            this.nombreToolStripMenuItem,
            this.fotoGrafiaToolStripMenuItem});
            this.editarProductoToolStripMenuItem.Name = "editarProductoToolStripMenuItem";
            this.editarProductoToolStripMenuItem.Size = new System.Drawing.Size(126, 24);
            this.editarProductoToolStripMenuItem.Text = "Editar Producto";
            // 
            // precioToolStripMenuItem
            // 
            this.precioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bebidaToolStripMenuItem1,
            this.comidaToolStripMenuItem1});
            this.precioToolStripMenuItem.Name = "precioToolStripMenuItem";
            this.precioToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.precioToolStripMenuItem.Text = "Precio";
            // 
            // bebidaToolStripMenuItem1
            // 
            this.bebidaToolStripMenuItem1.Name = "bebidaToolStripMenuItem1";
            this.bebidaToolStripMenuItem1.Size = new System.Drawing.Size(144, 26);
            this.bebidaToolStripMenuItem1.Text = "Bebida";
            this.bebidaToolStripMenuItem1.Click += new System.EventHandler(this.bebidaToolStripMenuItem1_Click);
            // 
            // comidaToolStripMenuItem1
            // 
            this.comidaToolStripMenuItem1.Name = "comidaToolStripMenuItem1";
            this.comidaToolStripMenuItem1.Size = new System.Drawing.Size(144, 26);
            this.comidaToolStripMenuItem1.Text = "Comida";
            // 
            // nombreToolStripMenuItem
            // 
            this.nombreToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comidaToolStripMenuItem3,
            this.bebidaToolStripMenuItem3});
            this.nombreToolStripMenuItem.Name = "nombreToolStripMenuItem";
            this.nombreToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.nombreToolStripMenuItem.Text = "Nombre";
            // 
            // comidaToolStripMenuItem3
            // 
            this.comidaToolStripMenuItem3.Name = "comidaToolStripMenuItem3";
            this.comidaToolStripMenuItem3.Size = new System.Drawing.Size(144, 26);
            this.comidaToolStripMenuItem3.Text = "Comida";
            this.comidaToolStripMenuItem3.Click += new System.EventHandler(this.comidaToolStripMenuItem3_Click);
            // 
            // bebidaToolStripMenuItem3
            // 
            this.bebidaToolStripMenuItem3.Name = "bebidaToolStripMenuItem3";
            this.bebidaToolStripMenuItem3.Size = new System.Drawing.Size(144, 26);
            this.bebidaToolStripMenuItem3.Text = "Bebida";
            // 
            // fotoGrafiaToolStripMenuItem
            // 
            this.fotoGrafiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bebidaToolStripMenuItem2,
            this.comidaToolStripMenuItem2});
            this.fotoGrafiaToolStripMenuItem.Name = "fotoGrafiaToolStripMenuItem";
            this.fotoGrafiaToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.fotoGrafiaToolStripMenuItem.Text = "Fotografia";
            this.fotoGrafiaToolStripMenuItem.Click += new System.EventHandler(this.fotoGrafiaToolStripMenuItem_Click);
            // 
            // bebidaToolStripMenuItem2
            // 
            this.bebidaToolStripMenuItem2.Name = "bebidaToolStripMenuItem2";
            this.bebidaToolStripMenuItem2.Size = new System.Drawing.Size(144, 26);
            this.bebidaToolStripMenuItem2.Text = "Bebida";
            this.bebidaToolStripMenuItem2.Click += new System.EventHandler(this.bebidaToolStripMenuItem2_Click);
            // 
            // comidaToolStripMenuItem2
            // 
            this.comidaToolStripMenuItem2.Name = "comidaToolStripMenuItem2";
            this.comidaToolStripMenuItem2.Size = new System.Drawing.Size(144, 26);
            this.comidaToolStripMenuItem2.Text = "Comida";
            this.comidaToolStripMenuItem2.Click += new System.EventHandler(this.comidaToolStripMenuItem2_Click);
            // 
            // editarDatosDeConexiToolStripMenuItem
            // 
            this.editarDatosDeConexiToolStripMenuItem.Name = "editarDatosDeConexiToolStripMenuItem";
            this.editarDatosDeConexiToolStripMenuItem.Size = new System.Drawing.Size(128, 24);
            this.editarDatosDeConexiToolStripMenuItem.Text = "Datos Conexion";
            this.editarDatosDeConexiToolStripMenuItem.Click += new System.EventHandler(this.editarDatosDeConexiToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(40, -238);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(945, 985);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBoxPDF
            // 
            this.pictureBoxPDF.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxPDF.Image")));
            this.pictureBoxPDF.Location = new System.Drawing.Point(953, 395);
            this.pictureBoxPDF.Name = "pictureBoxPDF";
            this.pictureBoxPDF.Size = new System.Drawing.Size(45, 48);
            this.pictureBoxPDF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxPDF.TabIndex = 2;
            this.pictureBoxPDF.TabStop = false;
            this.pictureBoxPDF.Click += new System.EventHandler(this.pictureBoxPDF_Click);
            // 
            // barToolStripMenuItem
            // 
            this.barToolStripMenuItem.Name = "barToolStripMenuItem";
            this.barToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.barToolStripMenuItem.Text = "Bar";
            this.barToolStripMenuItem.Click += new System.EventHandler(this.barToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1019, 464);
            this.Controls.Add(this.pictureBoxPDF);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "E-TRAY ADMINISTRADOR";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPDF)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem nuevoProductoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bebidaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comidaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarProductoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem precioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bebidaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem comidaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem nombreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fotoGrafiaToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem bebidaToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem comidaToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem comidaToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem bebidaToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem editarDatosDeConexiToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBoxPDF;
        private System.Windows.Forms.ToolStripMenuItem barToolStripMenuItem;
    }
}

